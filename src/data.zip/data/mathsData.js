const mathsData = {
    mainhd: "NCERT/SCIENCE - Physics",
    grads: [
      {
        gradehd: "GRADE 6",
        subTopics: [
          {
        
            id: 1,
            chaptarHd: "Chapter 1",
            chaptartitle: "Knowing our Numbers",
            subTopicList: [
              "1. Counting Numbers",
              "2. Comparing Numbers",
              "3. Ordering",
              "4. Shifting digits",
              "5. Place value",
              "6. Introducing large Numbers",
              "7. COMAS",
            ],
          },
       
        {  
          id: 2,
          chaptarHd: "Chapter 2",
          chaptartitle: "Whole Numbers",
          subTopicList: [
            "1. Predecessor and Successor",
            "2. Natural Numbers",
            "3. Whole Numbers",
            "4. The Number Line",
            "a. Addition Of Number Line",
            "b. ubtraction Of Number Line",
            "c. Multiplication Of Number Line",
          ],
        },
      ],
      }
    ]
  
 
  };


export default mathsData